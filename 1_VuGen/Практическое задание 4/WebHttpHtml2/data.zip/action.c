Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_add_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("collect", 
		"URL=https://www.google-analytics.com/collect?v=1&_v=j96&a=1216847946&t=pageview&_s=1&dl=chrome-extension%3A%2F%2Fcmedhionkhpnakcndndgjdbohmhepckk%2F_generated_background_page.html&dp=background.html%3Fv%3D5.1.7&ul=ru-ru&de=UTF-8&sd=24-bit&sr=1920x1080&vp=&je=0&_u=QCCAgEAB~&jid=1894632242&gjid=1297399786&cid=1036189143.1632641083&tid=UA-55554816-6&_gid=1271469547.1647872441&z=1342847721", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=", 
		"Snapshot=t136.inf", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=99", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t137.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("_ga_4NRQJ23B87=GS1.1.1632641092.1.0.1632641092.0; DOMAIN=api.adblock-for-youtube.com");

	web_add_cookie("_ga=GA1.2.392403629.1632641092; DOMAIN=api.adblock-for-youtube.com");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("adregex", 
		"URL=https://api.adblock-for-youtube.com/api/v1/adregex", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t138.inf", 
		"Mode=HTML", 
		LAST);

	web_url("update", 
		"URL=https://api.adblock-for-youtube.com/api/v1/update?v=5.1.7&xtid=cmedhionkhpnakcndndgjdbohmhepckk", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t139.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("IDE=AHWqTUnjnQBxJPRjRgKwU-LrdNGB4Qpp9CH96Gci0aVCKAHmOwoMD1cLJrEkz9f4zEU; DOMAIN=stats.g.doubleclick.net");

	web_add_header("Origin", 
		"chrome-extension://cmedhionkhpnakcndndgjdbohmhepckk");

	web_add_header("X-Client-Data", 
		"CI22yQEIprbJAQjEtskBCKmdygEIg9LKAQiSocsBCJ75ywEI54TMAQibnMwBCNCizAE=");

	web_custom_request("collect_2", 
		"URL=https://stats.g.doubleclick.net/j/collect?t=dc&aip=1&_r=3&v=1&_v=j96&tid=UA-55554816-6&cid=1036189143.1632641083&jid=1894632242&gjid=1297399786&_gid=1271469547.1647872441&_u=QCCAgEABAAAAAE~&z=988667406", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t140.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	web_add_cookie("SMSV=ADHTe-D1d5sbGUQRuoK53zoqSvLrr9x_ig1Xw2x-Wxsf6Kpdvq1SYs-TawYoZaJMaTMxhYdCa7c3PsAYLaCMJo6pz39aP9GNe_-cGgzjqNP3tfHOslGKZ1s; DOMAIN=accounts.google.com");

	web_add_cookie("S=billing-ui-v3=-IVxZDwm2-39J3rcffjvoVJiB-Na0SmE:billing-ui-v3-efe=-IVxZDwm2-39J3rcffjvoVJiB-Na0SmE; DOMAIN=accounts.google.com");

	web_add_cookie("LSOLH=_SVI_EPL3gY_r8fUCGAwiP01BRURIZl9xWS1SdFU4T2g3Z0dDWGpDR2JHNjFJWHcxYllBSGk2djU0V1ZiaXNPaU1xUTJnQi04REhPYnY1QQ_:27406394:3ee8; DOMAIN=accounts.google.com");

	web_add_cookie("user_id=106486266330361520242; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQI7JQB; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI51J482NLyi7JwKq9vq4JiEanLKt2wP5sdYRbKy__VXsxg0nKsGxkvS9UIaCnAU_UufIrMVjUjouzSL1zXaBjqnI37AA4urD8eTXpI1p5m9rESs0HW-HJcEQmERM3b9Sw68XKTQRpnAEnUOLrX2OtdZgRk3yw; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=AVQQ_LBvRPHAcZ0-RBrZQQuggJ49qJjFmwGPPj6RM869iXnL-Ogy90Xojx8; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=OVUaQplR0fvEXVpnZUGBnTJ2ZPRnoW3FbRFIxe6fm934TxHhRbVBs2VAm4LBJ6yiCjfmV-w8jqGennTHLQN0tadU0P6Wrc51ou6uQBL3wdu0NwM63ncZK0OAaiMdvPnlutMWj0uh8bdvzgkIYI25oEXi_emF7RBXsMPxhh7gdxr0GgVAUt_PMRKiAk7sdxaUzuswF4zVKO28NHc; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2022-03-27-04; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:CUjKLmQQv4zMMfklSZYFJkz4QMPVsDufbz-culJ78053JavcomjyT2ziiOKylrprADtjKmfvl-7f0NS29NF52OKg8yx5XA:LQe1YctkxBp5V1Ml; DOMAIN=accounts.google.com");

	web_revert_auto_header("DNT");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_header("Origin", 
		"https://www.google.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t141.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_add_cookie("NID=511=OVUaQplR0fvEXVpnZUGBnTJ2ZPRnoW3FbRFIxe6fm934TxHhRbVBs2VAm4LBJ6yiCjfmV-w8jqGennTHLQN0tadU0P6Wrc51ou6uQBL3wdu0NwM63ncZK0OAaiMdvPnlutMWj0uh8bdvzgkIYI25oEXi_emF7RBXsMPxhh7gdxr0GgVAUt_PMRKiAk7sdxaUzuswF4zVKO28NHc; DOMAIN=www.google.com");

	web_add_cookie("1P_JAR=2022-03-27-04; DOMAIN=www.google.com");

	web_url("ddljson", 
		"URL=https://www.google.com/async/ddljson?async=ntp:2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t142.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_url("newtab_promos", 
		"URL=https://www.google.com/async/newtab_promos", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t143.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("DNT", 
		"1");

	web_add_header("Origin", 
		"chrome-extension://bihmplhobchoageeokmgbdihknkjbknd");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("chrome_ext", 
		"URL=https://event.shelljacket.us/api/report/chrome_ext", 
		"Method=POST", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t144.inf", 
		"Mode=HTML", 
		"Body={\"event\":\"pageview\",\"payload\":{\"category\":1648357418921,\"connection-country\":\"optimal\",\"connection-status\":\"disconnected\",\"country\":\"ru\",\"hash\":\"tc559f8c0ea706a2ed8005738d5c64af4c\",\"id\":\"touch-vpn-chrome\",\"ts\":1648357418921,\"version\":\"4.1.0\"}}\n", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("X-Client-Data", 
		"CI22yQEIprbJAQjEtskBCKmdygEIg9LKAQjfgssBCJKhywEI6vLLAQie+csBCOeEzAEIpY7MAQjOmMwBCJuczAEIwZ7MAQiaocwBCNCizAE=");

	web_url("newtab_ogb", 
		"URL=https://www.google.com/async/newtab_ogb?hl=ru&async=fixed:0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t145.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("DNT", 
		"1");

	web_add_header("Origin", 
		"chrome-extension://bihmplhobchoageeokmgbdihknkjbknd");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("status", 
		"URL=https://api.hsselite.com/1/plain/status", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t146.inf", 
		"Mode=HTML", 
		"EncType=", 
		"BodyBinary=\n\\x89\\x01\\x08\\x05\\x12\"TC559f8c0ea706a2ed8005738d5c64af4c\\x1A\\x16com.touchvpn.extchrome \\xA4\\xB9\\x02*\\x06Chrome2\\x06Chrome:\\x0FWindows NT 10.0B\\x02ruR b1fbd5c88f0e45b10000000881315668", 
		LAST);

	web_add_header("X-Goog-Update-AppId", 
		"aapbdbdomjkkjkaonfhkkikfgjllcleb,aapocclcgogkmnckokdopfmhonfmgoek,aeajpdomellldbbkbeccocedicnehfhe,ahkjpbeeocnddjkakilopmfdlnjdpcdm,aohghmighlieiainnegkcijnfilokake,apdfllckaahabafndbhieahigkjlhalf,bihmplhobchoageeokmgbdihknkjbknd,blpcfgokakmgnkcojhhkbfbldkacnbeo,cmedhionkhpnakcndndgjdbohmhepckk,felcaaldnbdncclmgdcncolpebgiejap,ghbmnnjooekpmoecnnnilnnbdlolhkhi,gighmmpiobklfepjocnamgkkbiglidom,lbdmhpkmonokeldelekgfefldfboblbj,mfhcmdonhekjhfbjmeacdjbhlfgpjabp,nmmhkkegccagdldgiimedpiccmgmieda,"
		"ojplelelocihfchkdaebocpankipadmp,pjkljhegncpnkpknbcohdijeoejaedia,ponfpcnoihfmfllpaingbgckeeldkhle");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_auto_header("X-Goog-Update-Updater", 
		"chromecrx-99.0.4844.82");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=11:gUTRDe7JZER4M0x6Gj173mkQxVOgleTBF3JojZw2kVM&cup2hreq=998517fe1c9a75be1205ef4a6fbe1a7430e2268c6b4eb992dafe0c3e9eab9715", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t147.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"aapbdbdomjkkjkaonfhkkikfgjllcleb\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"1.5d10668974197fc78da78e47bd468cb4ad1960fddd087c86f0c65cf79ad6237f\"}]},\"ping\":{\"ping_freshness\":\"{7a4b1e90-569d-453f-b232-1b2f92506985}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"2.0.12\"},{\"appid\":\"aapocclcgogkmnckokdopfmhonfmgoek\",\""
		"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.0.10\"}]},\"ping\":{\"ping_freshness\":\"{5e70b324-7ccf-4863-b6a3-68f2f49d94ed}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"0.10\"},{\"appid\":\"aeajpdomellldbbkbeccocedicnehfhe\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.3\"}]},\"ping\":{\"ping_freshness\":\"{30a74dc4-ada5-49cf-84a9-80a2cd6cfdfb}\",\"rd\":5563},\"updatecheck\":{},"
		"\"version\":\"3\"},{\"appid\":\"ahkjpbeeocnddjkakilopmfdlnjdpcdm\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"external\",\"packages\":{\"package\":[{\"fp\":\"1.97f69affddad16dd92d72008ff7727e86149d54f9c2e9a5a66227f96738cfbfd\"}]},\"ping\":{\"ping_freshness\":\"{5d52e420-04f0-47f9-9a27-11626e34a31e}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"1.8.42.0\"},{\"appid\":\"aohghmighlieiainnegkcijnfilokake\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\""
		"package\":[{\"fp\":\"2.0.10\"}]},\"ping\":{\"ping_freshness\":\"{632d3ca4-674e-471b-ad9a-5db0c8f61a6d}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"0.10\"},{\"appid\":\"apdfllckaahabafndbhieahigkjlhalf\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.14.5\"}]},\"ping\":{\"ping_freshness\":\"{7095fe71-de38-4701-a22f-0b344b078520}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"14.5\"},{\"appid\":\"bihmplhobchoageeokmgbdihknkjbknd\",\""
		"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.4.1.0\"}]},\"ping\":{\"ping_freshness\":\"{9ba1eee0-1727-4b25-9861-948db477b396}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"4.1.0\"},{\"appid\":\"blpcfgokakmgnkcojhhkbfbldkacnbeo\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.4.2.8\"}]},\"ping\":{\"ping_freshness\":\"{4b5f7803-0d1e-409d-bfa9-704e71622865}\",\"rd\":5563},\"updatecheck"
		"\":{},\"version\":\"4.2.8\"},{\"appid\":\"cmedhionkhpnakcndndgjdbohmhepckk\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"1.82a60c82091faf59e280e9dccf434818fd2fe5ed2603c07b42962bc1f798e998\"}]},\"ping\":{\"ping_freshness\":\"{1691f76d-bc78-41e7-91a5-127bd81a2547}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"5.1.7\"},{\"appid\":\"felcaaldnbdncclmgdcncolpebgiejap\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages"
		"\":{\"package\":[{\"fp\":\"2.1.2\"}]},\"ping\":{\"ping_freshness\":\"{2f514646-b982-46fa-8a97-b42da724d7f3}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"1.2\"},{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"external\",\"packages\":{\"package\":[{\"fp\":\"1.8c309cfaa94404e912b8bdda17b94a22dc1f4203dac28f709dc47dde60467282\"}]},\"ping\":{\"ping_freshness\":\"{25ad6995-02ef-415a-ac6e-5c0160d8289b}\",\"rd\":5563},\"updatecheck\":{},\"version\":"
		"\"1.41.0\"},{\"appid\":\"gighmmpiobklfepjocnamgkkbiglidom\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"1.d93ec80a6738ff5bbdeed14c0fcbd87b09bb2e5f91c475330f28e0ba9e6b6513\"}]},\"ping\":{\"ping_freshness\":\"{9e68c4d5-4458-4f6b-8dc2-5da93e186e4d}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"4.44.0\"},{\"appid\":\"lbdmhpkmonokeldelekgfefldfboblbj\",\"cohort\":\"1::\",\"disabled\":[{\"reason\":1}],\"enabled\":false,\"installedby\":\""
		"internal\",\"packages\":{\"package\":[{\"fp\":\"2.3.3\"}]},\"ping\":{\"ping_freshness\":\"{13bc84f4-c625-4265-8900-930e7bfb110c}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"3.3\"},{\"appid\":\"mfhcmdonhekjhfbjmeacdjbhlfgpjabp\",\"cohort\":\"1::\",\"disabled\":[{\"reason\":8192}],\"enabled\":false,\"installedby\":\"external\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.4\"}]},\"ping\":{\"ping_freshness\":\"{a634799b-bcfc-4324-a9fc-7ece11962df2}\",\"rd\":5563},\"updatecheck\":{},\"version\":\""
		"1.0.4\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\"{6cc14bb0-c68c-40df-87e6-99d53a1a4bd1}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"1.0.0.6\"},{\"appid\":\"ojplelelocihfchkdaebocpankipadmp\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.3.20\"}]},\"ping\":{\"ping_freshness\":\""
		"{49bd185b-79c4-46e0-9fe6-69f8d10d69a7}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"3.20\"},{\"appid\":\"pjkljhegncpnkpknbcohdijeoejaedia\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"2.8.3\"}]},\"ping\":{\"ping_freshness\":\"{e8cce145-bb14-4aec-ab39-9e698eb541db}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"8.3\"},{\"appid\":\"ponfpcnoihfmfllpaingbgckeeldkhle\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\""
		"packages\":{\"package\":[{\"fp\":\"2.2.0.112\"}]},\"ping\":{\"ping_freshness\":\"{bada0e06-fc72-4175-a6ba-f61c95c06f38}\",\"rd\":5563},\"updatecheck\":{},\"version\":\"2.0.112\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"lang\":\"ru\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\""
		"10.0.22000.556\"},\"prodversion\":\"99.0.4844.82\",\"protocol\":\"3.1\",\"requestid\":\"{377ba78e-e377-4f9b-bb4b-c5e48b5d9b5f}\",\"sessionid\":\"{376f58e7-36cc-4482-96c9-a173c43acad6}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.122\"},\"updaterversion\":\"99.0.4844.82\"}}", 
		LAST);

	web_add_header("X-Goog-Update-AppId", 
		"ckcmdpmhiekiihmfjffdehhbhgllpapg,ipjjmoaaiokdonnldckdhmhojapklmdi,phcogmapnhgdbmilclanafaljonkjppa");

	web_url("crx", 
		"URL=https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=99.0.4844.82&lang=ru&acceptformat=crx3&x=id%3Dckcmdpmhiekiihmfjffdehhbhgllpapg%26v%3D0.0.0.0%26installedby%3Dinternal%26uc%26ping%3Dr%253D7%2526e%253D0%2526dr%253D1&x=id%3Dipjjmoaaiokdonnldckdhmhojapklmdi%26v%3D0.0.0.0%26installedby%3Dinternal%26uc%26ping%3Dr%253D7%2526e%253D1&x="
		"id%3Dphcogmapnhgdbmilclanafaljonkjppa%26v%3D0.0.0.0%26installedby%3Dinternal%26uc%26ping%3Dr%253D7%2526e%253D0%2526dr%253D1", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t148.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Goog-Update-Interactivity");

	web_revert_auto_header("X-Goog-Update-Updater");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Origin", 
		"chrome-extension://bihmplhobchoageeokmgbdihknkjbknd");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("payment_popup", 
		"URL=https://api.hsselite.com/1/plain/config/payment_popup", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t149.inf", 
		"Mode=HTML", 
		"EncType=", 
		"BodyBinary=\n\\x89\\x01\\x08\\x05\\x12\"TC559f8c0ea706a2ed8005738d5c64af4c\\x1A\\x16com.touchvpn.extchrome \\xA4\\xB9\\x02*\\x06Chrome2\\x06Chrome:\\x0FWindows NT 10.0B\\x02ruR b1fbd5c88f0e45b10000000881315668", 
		LAST);

	lr_start_transaction("Go_To_Flights");

	lr_start_transaction("HomePage");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(26);

	web_url("WebTours", 
		"URL=http://127.0.0.1:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t150.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(9);

	web_submit_form("login.pl", 
		"Snapshot=t151.inf", 
		ITEMDATA, 
		"Name=username", "Value=sergey", ENDITEM, 
		"Name=password", "Value=pass", ENDITEM, 
		LAST);

	return 0;
}